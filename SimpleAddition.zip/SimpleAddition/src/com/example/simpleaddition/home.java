package com.example.simpleaddition;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class home extends Activity {

	
	Double num1,num2,sum;
    Button b1,b2,b3,b4;  
    EditText e1,e2,e3;
    
    
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        
        e1=(EditText)findViewById(R.id.editText1);
        e2=(EditText)findViewById(R.id.editText2);
        e3=(EditText)findViewById(R.id.editText3);
   
        b1=(Button)findViewById(R.id.button1);
        b1.setOnClickListener(new OnClickListener() {
			
        	public void onClick(View v) {
        		num1 = Double.parseDouble(e1.getText().toString());
        		num2 = Double.parseDouble(e2.getText().toString());
        		sum = num1 + num2;
        		
        		e3.setText(Double.toString(sum));
        		
        	}
        });
        
        
        
        b2=(Button)findViewById(R.id.button2);
        b2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				
				num1 = Double.parseDouble(e1.getText().toString());
        		num2 = Double.parseDouble(e2.getText().toString());
        		sum = num1 - num2;
        		e3.setText(Double.toString(sum));
        		Toast.makeText(getApplicationContext(), String.valueOf(sum), Toast.LENGTH_SHORT).show();
			}
		});



 
    }

  
}